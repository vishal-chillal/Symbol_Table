#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct symbol_table
{
  int index,lineNo;
  char *name,*type,*section,*val;
  struct symbol_table *pNext;

}sysTab;

typedef struct text_symb_table
{
  int index,lineNo,val;
  char *name,*type,*section;
  struct symbol_table *pNext;

}TsysTab;

int addEntry (sysTab **head,char *name,char *sec,char *val,char *sysType, int lineNo);
int print_table( sysTab **head);
int text_print_table(TsysTab **head);
int text_entry (TsysTab **head,char *name,char *sec,int val,char *sysType, int lineNo);
//int conversion (int inp, hex var);
